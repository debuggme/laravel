<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;
use App\Http\Requests;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;


class demoController extends Controller{
	 /*public function insertform(){
		return view('home');
	}
    public function insert(Request $request){
		$name = $request->input('name');
		$email = $request->input('email');
		$phone = $request->input('phone');
		$city = $request->input('city');
		$data=array('name'=>$name,"email"=>$email,"phone"=>$phone,"city"=>$city);
		DB::table('infotb')->insert($data);
		echo "Record inserted successfully.<br/>";
		echo '<a href = "/insert">Click Here</a> to go back.';
	}*/
	public function index(Request $request){
    //return "Democontroller";
	$name = $request->input('name');
	$email = $request->input('email');
	$phone = $request->input('phone');
	$city = $request->input('city');
	/*$data=$name." ".$email." ".$phone." ".$city;*/
	$data=array('name'=>$name,"email"=>$email,"phone"=>$phone,"city"=>$city);
	DB::table('infotb')->insert($data);
	return response("OK", 200)
                  ->header('Content-Type', 'text/plain');
  }
  
  
  public function getData($id=null){
    $value=DB::table('infotb')->orderBy('id', 'asc')->get(); 
	return json_encode($value);
    exit;
  }
  

  
public function deleteData($id=null){
	DB::table('infotb')->where('id','=',$id)->delete();
    return redirect('home');
  }
  
  public function fetchData($id=null)
  {
	   $value=DB::table('infotb')->where('id', $id)->get();
       return json_encode($value);	   
  }
  
 public function updateData(Request $request){
	 $name = $request->input('name');
	 $email = $request->input('email');
	 $phone = $request->input('phone');
	 $city = $request->input('city');
	 $id=$request->input('id');
	 $data=array('name'=>$name,"email"=>$email,"phone"=>$phone,"city"=>$city);
	 DB::table('infotb')->where('id',$id)->update($data);
	 return response("OK", 200)
                  ->header('Content-Type', 'text/plain');
 }
 
//filters





public function filterCity($val)
    {
		
	$value=DB::table('infotb')->where('city', $val)->get();
	return json_encode($value);
    //return response($val, 200)
      //            ->header('Content-Type', 'text/plain');
        
 

}


public function filterPhone($val)
    {
		
	$value=DB::table('infotb')->where('phone','=',$val)->get();
	return json_encode($value);
    //return response($val, 200)
                 // ->header('Content-Type', 'text/plain');
        
 

}
}