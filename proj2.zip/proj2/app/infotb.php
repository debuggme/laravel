<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
class infotb extends Model
{

   public static function insertData($data){

     $value=DB::table('infotb')->where('email', $data['email'])->get();
     if($value->count() == 0){
       $insertid = DB::table('infotb')->insertGetId($data);
       return $insertid;
     }else{
       return 0;
     }

   }

}
