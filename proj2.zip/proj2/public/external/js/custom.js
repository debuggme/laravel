$(function()
{
	function fillData()
	{
	$.ajax({
	url:'/getData',
	type:'GET',
	success:function(data)
	{
		//alert(data);
		obj = JSON.parse(data);
		//Object.keys(obj).length
		
		for(i=0;i<obj.length;i++)
		{
			str="<tr>";
			str=str+"<td>"+obj[i].name+"</td>";
			str=str+"<td>"+obj[i].email+"</td>";
			str=str+"<td>"+obj[i].phone+"</td>";
			str=str+"<td>"+obj[i].city+"</td>";
			str=str+"<td><a href='/deleteData/"+obj[i].id+"'>Delete</a></td>";
			str=str+"<td><a onclick='edit("+obj[i].id+")'>Edit</a></td>";
			str=str+"</tr>";
			$('#dcon').append(str);
		}
	}
	
    });
	}
	fillData();
	$('#btnSave').click(function()
	{
	var cname = $('#txtname').val();
    var cemail = $('#txtemail').val();
	var cphone = $('#txtphone').val();
	var ccity = $('#txtcity').val();
	//alert(name+" "+email+" "+phone+" "+city);
	$.ajax({
		url:'/insert',
		type:'POST',
		headers:{'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
		data:{name:cname,email:cemail,phone:cphone,city:ccity},
		success:function(data)
		{
			
			$('#dcon').empty();
			fillData();
		}
	});	
	});
	
	//Update Contact
	$('#btnUpdate').click(function(){
		
		//Pasted
	var cname = $('#uptxtname').val();
    var cemail = $('#uptxtemail').val();
	var cphone = $('#uptxtphone').val();
	var ccity = $('#uptxtcity').val();
	var cid= $('#txtid').val();
	//alert(cname+" "+cemail+" "+cphone+" "+ccity);
	$.ajax({
		url:'/updateData',
		type:'POST',
		headers:{'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
		data:{name:cname,email:cemail,phone:cphone,city:ccity,id:cid},
		success:function(data)
		{
			//alert(data);
			$('#dcon').empty();
			fillData();
		}
	});	
		//Pasted
		
	});
	//Update Contact
	
	
	//RESET DATA
	$("#resetData").click(function() {
  $("#phone").val("").trigger("input");
  $('#mySelector').prop('selectedIndex',0);
  
  $('#dcon').empty();
  fillData();
});
	//RESET  DATA
});
function edit(id)
{
	//The id fetched here
	$.ajax({
		url:'/fetchData/'+id,
		type:'GET',
		success:function(data)
		{
			obj = JSON.parse(data);
			$('#uptxtname').val(obj[0].name);
			$('#uptxtemail').val(obj[0].email);
			$('#uptxtphone').val(obj[0].phone);
			$('#uptxtcity').val(obj[0].city);
			$('#txtid').val(obj[0].id);
			$('#updateModal').modal('show');
		}
	});
}
/*Filter Function Ajax */



$('#mySelector').change(function() {
  var v1=$(this).val();
  $.ajax({
		url:'/filterData/'+v1,
		type:'get',
		success:function(data)
		{
		   //pasted 
		   
		obj = JSON.parse(data);
		//Object.keys(obj).length
		$('#dcon').empty();
		for(i=0;i<obj.length;i++)
		{
			str="<tr>";
			str=str+"<td>"+obj[i].name+"</td>";
			str=str+"<td>"+obj[i].email+"</td>";
			str=str+"<td>"+obj[i].phone+"</td>";
			str=str+"<td>"+obj[i].city+"</td>";
			str=str+"<td><a href='/deleteData/"+obj[i].id+"'>Delete</a></td>";
			str=str+"<td><a onclick='edit("+obj[i].id+")'>Edit</a></td>";
			str=str+"</tr>";
			$('#dcon').append(str);
		}
			//pasted
		}
	});
});



$('#phone').keyup(function () {
	var v1=$(this).val();
	//alert(v1);
	$.ajax({
		url:'/filterPhone/'+v1,
		type:'get',
		success:function(data)
		{
			//alert(data);
			//pasted 
		   
		obj = JSON.parse(data);
		//Object.keys(obj).length
		$('#dcon').empty();
		for(i=0;i<obj.length;i++)
		{
			str="<tr>";
			str=str+"<td>"+obj[i].name+"</td>";
			str=str+"<td>"+obj[i].email+"</td>";
			str=str+"<td>"+obj[i].phone+"</td>";
			str=str+"<td>"+obj[i].city+"</td>";
			str=str+"<td><a href='/deleteData/"+obj[i].id+"'>Delete</a></td>";
			str=str+"<td><a onclick='edit("+obj[i].id+")'>Edit</a></td>";
			str=str+"</tr>";
			$('#dcon').append(str);
		}
			//pasted
			
		}

});
});



