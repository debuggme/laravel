<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
					
					
					<!--Filters-->
					 
					
				   <select id='mySelector' style="color:#fff; background-color:#343a40; border-color:#343a40; border-radius:.25rem; padding:.5rem .75rem; text-align: center; white-space: nowrap; vertical-align: middle; text-align: center;">
				   <option value="">Please Select City</option>
				   <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($item->city); ?>"><?php echo e($item->city); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				   </select>
				   <input type="text" placeholder="Phone" id="phone" style="border-color:#343a40; border-radius:.25rem; padding:.5rem .75rem; text-align: center; white-space: nowrap; vertical-align: middle; text-align: center;">
	
					
					<input type="reset" id="resetData" value="Reset" class="btn btn-dark" />
					<!--End Filters-->
					
					
					
					
				<input type="button" class="btn btn-dark pull-right" value="AddNew" data-toggle="modal" data-target="#exampleModal">
				
				<!--<div class="form-group">
					<input type="hidden" name="_token" id="csrf" value="<?php echo e(Session::token()); ?>">
					<label for="email">Name:</label>
					<input type="text" class="form-control" id="txtname" placeholder="Enter Name" name="name">
					</div>
				<div class="form-group">
					<label for="email">Email:</label>
					<input type="email" class="form-control" id="txtemail" placeholder="Enter Email" name="email">
				</div>
				<div class="form-group">
				<label for="email">Phone:</label>
				<input type="text" class="form-control" id="txtphone" placeholder="Enter Phone" name="phone">
				</div>
				<div class="form-group">
					<label for="email">City:</label>
					<input type="text" class="form-control" id="txtcity" placeholder="Enter City" name="city">
				</div>
				<button type="submit" class="btn btn-primary" id="butsave">Submit</button>
				</div>-->
      <table class="table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
		  <th>Phone</th>
		  <th>City</th>
          <th></th>
        </tr>
      </thead>
      <tbody id="dcon">
        
      </tbody>
    </table>  
                </div>
            </div>
        </div>
    </div>
</div>
<!--Modal-->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <!--Pasted-->
	   <div class="form-group">
					<input type="hidden" name="_token" id="csrf" value="<?php echo e(Session::token()); ?>">
					<label for="email">Name:</label>
					<input type="text" class="form-control" id="txtname" placeholder="Enter Name" name="name">
					</div>
				<div class="form-group">
					<label for="email">Email:</label>
					<input type="email" class="form-control" id="txtemail" placeholder="Enter Email" name="email">
				</div>
				<div class="form-group">
				<label for="number">Phone:</label>
				<input type="text" class="form-control" id="txtphone" placeholder="Enter Phone" name="phone">
				</div>
				<div class="form-group">
					<label for="text">City:</label>
					<input type="text" class="form-control" id="txtcity" placeholder="Enter City" name="city">
				</div>
								
       <!--Pasted-->	   
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="btnSave" data-dismiss="modal">Save changes</button>
      </div>
    </div>
  </div>
</div>
<!--Modal-->
<!--Update Modal-->
<!--Modal-->
<div class="modal fade" id="updateModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="updateModal">UpdateContact</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <!--Pasted-->
	   <div class="form-group">
					<input type="hidden" name="_token" id="csrf" value="<?php echo e(Session::token()); ?>">
					<label for="email">Name:</label>
					<input type="text" class="form-control" id="uptxtname" placeholder="Enter Name" name="name">
					</div>
				<div class="form-group">
					<label for="email">Email:</label>
					<input type="email" class="form-control" id="uptxtemail" placeholder="Enter Email" name="email">
				</div>
				<div class="form-group">
				<label for="number">Phone:</label>
				<input type="text" class="form-control" id="uptxtphone" placeholder="Enter Phone" name="phone">
				</div>
				<div class="form-group">
					<label for="text">City:</label>
					<input type="text" class="form-control" id="uptxtcity" placeholder="Enter City" name="city">
				</div>
				<input type="hidden" id="txtid">
								
       <!--Pasted-->	   
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="btnUpdate" data-dismiss="modal">Save changes</button>
      </div>
    </div>
  </div>
</div>
<!--Modal-->
<!--Update Modal-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\lara\proj2\resources\views/home.blade.php ENDPATH**/ ?>