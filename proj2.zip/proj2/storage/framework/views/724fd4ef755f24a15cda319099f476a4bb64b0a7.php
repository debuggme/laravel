<?php echo e($slot); ?>

<?php /**PATH C:\Users\user\Documents\lara\proj2\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>